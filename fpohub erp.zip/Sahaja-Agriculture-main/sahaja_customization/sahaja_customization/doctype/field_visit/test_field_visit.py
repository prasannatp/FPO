# -*- coding: utf-8 -*-
# Copyright (c) 2022, Raaj Tailor and Contributors
# See license.txt
from __future__ import unicode_literals

# import frappe
import unittest

class TestFieldVisit(unittest.TestCase):
	pass
