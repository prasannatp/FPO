// Copyright (c) 2022, Raaj Tailor and contributors
// For license information, please see license.txt

frappe.ui.form.on('Village', {
	// refresh: function(frm) {

	// }
});
